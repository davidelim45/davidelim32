package github22;

public class vezba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
