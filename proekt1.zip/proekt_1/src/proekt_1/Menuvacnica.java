package proekt_1;

public class Menuvacnica {

	public static void main(String[] args) {
		double x=50, y=61.7;
		double suma2 = x*y;
		System.out.println (suma2);

	}

}
