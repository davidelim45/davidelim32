package proekt_1;

public class Smetka {

	public static void main(String[] args) {
	double praski=50;
	int jabolki=32;
	int kompiri=20;
	double rezultat;
	rezultat=(jabolki*2)+(kompiri*5)+(praski*2.5);
	System.out.println("smetkata iznesuva");
    System.out.println(rezultat);
	}

}
