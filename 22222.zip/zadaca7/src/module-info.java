module zadaca7 {
}